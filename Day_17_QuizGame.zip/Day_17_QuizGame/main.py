from question_model import Question
from data import question_data
from quiz_brain import QuizBrain
question_bank = []
for quest_and_answer in question_data:
    question_text = (quest_and_answer["text"])
    question_answer = (quest_and_answer["answer"])
    new_question = Question(question_text, question_answer)
    question_bank.append(new_question)
print(question_bank[0].answer)

quiz = QuizBrain(question_bank)
quiz.next_question()
while quiz.still_has_questions():
    quiz.next_question()
print("You've completed the quiz")
print(f"Your final score is {quiz.score}/{quiz.question_number}")
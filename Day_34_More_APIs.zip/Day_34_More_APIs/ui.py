THEME_COLOR = "#375362"
from tkinter import *
from quiz_brain import QuizBrain

class QuizInterface:
    def __init__(self, quizBrain: QuizBrain):
        self.quiz = quizBrain
        self.window = Tk()
        self.window.title("Quizzler")
        self.window.config(background=THEME_COLOR, pady=20, padx=20)

        self.score = Label(text="Score: 0",fg="white", bg=THEME_COLOR, font=("ariel", 12), pady=20)
        self.score.grid(row=0, column=1)

        self.q_canvas = Canvas(width=300, height=250, highlightthickness=0, bg="white")
        self.q_text = self.q_canvas.create_text(150, 125,
                                                text= "fu",
                                                width=280,
                                                fill=THEME_COLOR ,font=("ariel", 20, "italic"))
        self.q_canvas.grid(column=0, row=1, columnspan=2, pady=50)


        self.true_btn_img = PhotoImage(file="images/true.png")
        self.true_btn = Button(image=self.true_btn_img, highlightthickness=0, command=self.true_pressed)
        self.true_btn.grid(row=2, column=0)
        self.get_q()
        self.false_btn_img = PhotoImage(file="images/false.png")
        self.false_btn = Button(image=self.false_btn_img, highlightthickness=0, command=self.false_pressed)
        self.false_btn.grid(row=2, column=1,)

        red_btn = Canvas
        self.window.mainloop()
    def get_q(self):
        self.q_canvas.config(background="white")
        if self.quiz.still_has_questions():

           self.score.config(text=f"Score: {self.quiz.score}")
           q_tex = self.quiz.next_question()
           self.q_canvas.itemconfig(self.q_text, text=q_tex)
        else:
            self.q_canvas.itemconfig(self.q_text, text="Ur done nerd")
            self.true_btn.config(state="disabled")
            self.false_btn.config(state="disabled")
    def true_pressed(self):
        self.feedback(self.quiz.check_answer("True"))

    def false_pressed(self):
        self.feedback(self.quiz.check_answer("True"))
    def feedback(self, is_right):
        if is_right:
            self.q_canvas.config(background="green")
            self.window.after(1000, self.get_q)

        else:
            self.q_canvas.config(background="red")
            self.window.after(1000, self.get_q)
